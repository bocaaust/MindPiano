//
//  iAdsAddon.h
//

#import "CodeaAddon.h"

#import <Foundation/Foundation.h>

@interface iAdsAddon : CodeaAddon

+ (instancetype) sharedInstance;

@end

