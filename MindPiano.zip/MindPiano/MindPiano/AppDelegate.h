//
//  AppDelegate.h
//  MindPiano
//
//  Created by Austin Lubetkin on Tuesday, December 13, 2016
//  Copyright (c) Austin Lubetkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class StandaloneCodeaViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) StandaloneCodeaViewController *viewController;

@end
