ClassName = class()

function ClassName:init(x)
    -- you can accept and set parameters here
    self.x = x
end

function ClassName:draw()
    -- Codea does not automatically call this method
end

function ClassName:touched(touch)
    -- Codea does not automatically call this method
end
